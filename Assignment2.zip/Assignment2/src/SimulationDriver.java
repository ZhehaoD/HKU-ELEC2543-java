public class SimulationDriver {

  public static void main(String[] args) {

    RRSimulation sim = new RRSimulation();
    
    sim.run(2);
  }
}
